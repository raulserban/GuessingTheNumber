﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuessingTheNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            GetAppInfo();

            GreetUser();

            while (true)
            {

                // Init correct number
                // int correctNumber = 7;

                // Create a new Random object
                Random random = new Random();
                int correctNumber = random.Next(1, 10);


                // Init guess var
                int guess = 0;

                Console.WriteLine("Guess a number between 1 and 10");

                // While guess is not correct
                while (guess != correctNumber)
                {
                    // Get users input
                    string input = Console.ReadLine();

                    // Make sure its a number
                    if (!int.TryParse(input, out guess))
                    {
                        // Tell the user he did not introduce a number
                        PrintColorMessage(ConsoleColor.Red, "Please give us a real number");

                        // Keep going
                        continue;
                    }

                    // Cast to int and put in guess
                    guess = Int32.Parse(input);

                    // Match guess to correct number
                    if (guess != correctNumber)
                    {
                        // Tell the user that the number is wrong
                        PrintColorMessage(ConsoleColor.Red, "Wrong number, please try again");
                    }
                }

                // Tell the user that the number is correct
                PrintColorMessage(ConsoleColor.Yellow, "COREEEEECT !!! This is the number !");

                // Ask to play again
                Console.WriteLine("Play again? Y/N");

                // Get answer
                string answer = Console.ReadLine().ToUpper();

                // 
                if (answer == "Y")
                {
                    continue;
                }
                else if (answer == "N")
                {
                    break;
                }
                else
                {
                    break;
                }
            }
        }

        static void GetAppInfo()
        {
            // Set details of the app
            string appName = "Guessing the number";
            string appVersion = "1.0.0";
            string appAuthor = "Raul Serban";

            // Change text color
            Console.ForegroundColor = ConsoleColor.Green;

            // Write app info
            Console.WriteLine("{0}: Version {1} by {2}", appName, appVersion, appAuthor);

            // Reset text color
            Console.ResetColor();
        }

        static void GreetUser()
        {
            // Ask user name
            Console.WriteLine("What is your name?");

            // Get user input
            string inputOfUser = Console.ReadLine();
            string userName = char.ToUpper(inputOfUser[0]) + inputOfUser.Substring(1);

            Console.WriteLine("Hello {0}, let's play a game...", userName);
        }

        static void PrintColorMessage(ConsoleColor color, string message)
        {
            // Change text color
            Console.ForegroundColor = color;

            // Write the message
            Console.WriteLine(message);

            // Reset text color
            Console.ResetColor();
        }
    }
}
